package com.example.catfactsapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    val instance: ApiRequest
        get() {
            val restAdapter = Retrofit.Builder().baseUrl(MainActivity.BASEURL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiRequest::class.java)
            return restAdapter
        }
}