package com.example.catfactsapp


import retrofit2.Call
import retrofit2.http.GET

interface ApiRequest {

    @GET("fact")
    fun getfacts():Call<Data>

}