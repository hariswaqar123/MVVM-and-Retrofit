package com.example.catfactsapp

import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.drawable.InsetDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.catfactsapp.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    val bind by lazy{

        ActivityMainBinding.inflate(layoutInflater)

    }

    companion object {
        const val BASEURL = "https://catfact.ninja/"
    }

    private lateinit var viewModel: FactsViewModel

    val handler = Handler()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(bind.root)

        handler.postDelayed({

            bind.textView2.visibility = View.GONE
            bind.progressBar2.visibility = View.GONE
            bind.tvTitle.visibility = View.VISIBLE
            bind.btnReload.visibility = View.VISIBLE

        }, 3000)

        viewModel = ViewModelProvider(this).get(FactsViewModel::class.java)

        viewModel.fact.observe(this@MainActivity,object : Observer<String?> {
            override fun onChanged(t: String?) {
                bind.progressBar.visibility = View.GONE
                bind.textView.visibility = View.VISIBLE
                bind.textView.text = t
            }
        })

        bind.progressBar.visibility = View.GONE
        bind.textView.visibility = View.GONE

        bind.btnReload.setOnClickListener {
            bind.progressBar.visibility = View.VISIBLE
            bind.textView.visibility = View.GONE
            getData()
        }
    }
    fun getData() {
        ApiClient.instance.getfacts().enqueue(object : Callback<Data?> {
            override fun onResponse(
                call: Call<Data?>,
                response: Response<Data?>
            ) {
                val data = response.body()
                viewModel.fact.value = data!!.fact
            }

            override fun onFailure(call: Call<Data?>, t: Throwable) {
                Log.d("TAG", "onFailure: ${t.message}")
            }
        })
    }

    override fun onBackPressed() {

        AlertDialog.Builder(this@MainActivity)
            .setTitle("Exit")
            .setMessage("Are You Sure You Want To Exit?")
            .setIcon(R.drawable.alert)
            .setPositiveButton("Yes",DialogInterface.OnClickListener { _, _ -> finish() })
            .setNegativeButton("No",DialogInterface.OnClickListener{ dialog, _ -> dialog.dismiss() })
            .show()

    }

}