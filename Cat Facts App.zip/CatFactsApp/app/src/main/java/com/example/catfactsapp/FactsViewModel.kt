package com.example.catfactsapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class FactsViewModel: ViewModel() {

    val fact = MutableLiveData<String>()
    val length = MutableLiveData<Int>()
}