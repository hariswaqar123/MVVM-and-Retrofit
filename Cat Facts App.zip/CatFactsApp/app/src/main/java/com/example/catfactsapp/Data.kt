package com.example.catfactsapp

data class Data(val fact:String, val length: Int )